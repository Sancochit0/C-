﻿int edad;
//Declaracion de la variable que usaremos

//Pedimos su edad al usuario
Console.Write("¿Que edad tienes? ");
//Convertimos la edad a entero
edad = Convert.ToInt32(Console.ReadLine());

//Aqui ponemos las condiciones que queremos que se cumplan
//Iniciando que desde 50 hasta en adelante, ya es un abuelo
if (edad >= 50)
    {
        Console.WriteLine("Ya eres un abuelo bro");
    }
 //En esta debemos colocar un rango utilizando &&, que seria de 30 a 49
else if (edad >= 30)
    {
        Console.WriteLine("Ya tas muy mayor, eres un adulto bro");
    }
else
{
    //Por ultimo, si ningunad e esas se cumple, este es el mensaje
    Console.WriteLine("ah no, tu ere un niño todavia");
}
