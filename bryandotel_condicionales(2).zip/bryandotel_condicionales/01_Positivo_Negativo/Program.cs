﻿int num;
//Declaracion de variables

//Pedimos el numero al usuario
Console.Write("Ingresa un numero: ");
//Lo convertimos a entero
num = Convert.ToInt32(Console.ReadLine());

//Proceso
if (num >= 0)
{
    //Mensaje de salida si es positivo
    Console.WriteLine("El numero " + num + " es positivo");
}   
else
{
    //Mensaje de salida si es negativo
    Console.WriteLine("El numero " + num + " es negativo");
}

