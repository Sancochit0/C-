﻿int num;
int dig1;
int dig2;
//Declaracion de variables

//Pedir el numer al usuario
Console.Write("Ingresa un numero de 2 digitos: ");
//Convertimos a int
num = Convert.ToInt32(Console.ReadLine());

if (num <10 || num > 99)
{
    Console.WriteLine("Numero invalido");
}
else
{
    dig1 = num / 10;
    dig2 = num % 10;

    if (dig1 % dig2 == 0)
    {
        Console.WriteLine(dig1 + " es multiplo de " + dig2);
    }

    else
    {
        Console.WriteLine(dig1 + " no es multiplo de " + dig2);
    }
}