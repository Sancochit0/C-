﻿int num;
int dig1;
int dig2;
int suma;
//Variables

//Pedimos num
Console.Write("Ingresa un numero de 2 digitos: ");
//Convertimos a int
num = Convert.ToInt32(Console.ReadLine());

//Proceso


if (num < 10 || num > 99)
{
    //Mensaje de salida si se cumple
    Console.WriteLine("Numero invalido ");
}
else
{
    dig1 = num / 10;
    dig2 = num % 10;
    suma = dig1 + dig2;
    Console.WriteLine("La suma de sus dos digitos es: " + suma);
}
