﻿int num;
int dig1;
int dig2;
string dig1paroimpar;
string dig2paroimpar;
//Variables

//Pedimos numero
Console.Write("Ingresa un numero de 2 digitos: ");
//Convertimos
num = Convert.ToInt32(Console.ReadLine());

dig1 = num / 10;
dig2 = num % 10;

if (dig1 % 2 == 0)
{
    dig1paroimpar = " es par ";
}
else
{
    dig1paroimpar = " es impar ";
}

if (dig2 % 2 == 0)
{
    dig2paroimpar = " es par ";
}
else
{
    dig2paroimpar = " es impar ";
}

Console.WriteLine("El primer digito" + dig1paroimpar + "y el segundo" + dig2paroimpar);

