﻿int num;
int dig1;
int dig2;
//Declaracion de variables

//Pedimos el numero al usuario
Console.Write("Ingresa un numero de 2 digitos: ");
//Convertimos a entero
num = Convert.ToInt32(Console.ReadLine());

//Proceso
dig1 = num / 10;
dig2 = num % 10;


if (num < 10 || num > 99)
{
    Console.WriteLine("Numero invalido");
}
else
{
    if (dig1 == dig2)
{
    //Mensaje de salida si la condicion se cumple
    Console.WriteLine(dig1 + " y " + dig2 + " son iguales");
}
else
{  
    //Mensaje de salida sino se cumple la condicion 
    Console.WriteLine(dig1 + " y " + dig2 + " no son iguales");
}
}

