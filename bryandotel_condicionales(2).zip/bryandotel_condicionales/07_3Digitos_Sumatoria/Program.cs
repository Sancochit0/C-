﻿int num;
int dig1;
int dig2;
int dig3;
int sumafinal;
//Declaracion de variables

//Pedimos el numero
Console.Write("Ingresa un numero de 3 digitos: ");
//Convertimos el numero a int
num = Convert.ToInt32(Console.ReadLine());

//Validacion del numero ingresado
if (num <100 || num >999)
{
    //mensaje de salida si se cumple
    Console.WriteLine("Numero invalido");
}
else
{
    //proceso
    dig1 = num / 100;
    dig2 = (num % 100) / 10;
    dig3 = num % 10;
    sumafinal = dig1 + dig2 + dig3;
    
    //mensaje de salida mas el resultado luego del proceso 
    Console.WriteLine("La suma final de su numero es: " + sumafinal);
}
