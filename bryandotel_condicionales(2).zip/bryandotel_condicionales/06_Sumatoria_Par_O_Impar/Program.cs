﻿int num;
int dig1;
int dig2;
int suma;
//Variables declaradas

//Pedimos el numero
Console.Write("Ingresa un numero de dos digitos: ");
//Lo convertimos a entero
num = Convert.ToInt32(Console.ReadLine());

//Validaacion
if (num <10 || num > 99)
{
    //Mensaje de salida si la condicion se cumple
    Console.WriteLine("Numero invalido");
}
else
{
    //Proceso para sacar ambos digitos y sumarlos
    dig1 = num / 10;
    dig2 = num % 10;
    suma = dig1 + dig2;

    //proceso para validar si es par
    if (suma % 2 == 0)
    {
        //mensaje de salida si lo es
        Console.WriteLine("El numero "+ suma + " es par");
    }
    else
    {   //mensaje de salida sino lo es
        Console.WriteLine("El numero " + suma + " es impar");
    }
}
