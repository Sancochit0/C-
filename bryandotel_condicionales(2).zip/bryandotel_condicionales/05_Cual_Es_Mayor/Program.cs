﻿int num1;
int num2;
//Declaracion de variables

//Pedimos el primer numero 
Console.Write("Ingresa num1: ");
//Convertimos a entero
num1 = Convert.ToInt32(Console.ReadLine());
//Pedimos el segundo numero
Console.Write("Ingresa num2: ");
//Convertimos a entero
num2 = Convert.ToInt32(Console.ReadLine());

//Proceso de como sabemos si uno es mayor
if (num1 > num2)
{
    //Mensaje de salida cuando se cumple la condicion
    Console.WriteLine("El numero 1 es mayor");
}
else
{   //Mensaje de salida cuando no se cumple la condicion
    Console.WriteLine("El numero 2 es mayor");
}
