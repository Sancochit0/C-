﻿using System.Reflection;

int n1;
int n2;
int n3;
//Declaracion de variables

//Interacciones con el usuario y entradas de datos
Console.Write("Ingresa el n1: ");
n1 = Convert.ToInt32(Console.ReadLine());
Console.Write("Ingresa el n2: ");
n2 = Convert.ToInt32(Console.ReadLine());
Console.Write("Ingresa el n3: ");
n3 = Convert.ToInt32(Console.ReadLine());

//Iniciamos valiando si el n1 es el mejor 
if(n1 <= n2 && n1 <= n3)
{
    if (n2 <= n3) //Ahora vemos cual es menor entre ambos si la condicion se cumple
        Console.WriteLine("El menor es: " + n1 + " luego " + n2 + " y finalmente " + n3); 
    else
        Console.WriteLine("El menor es: " + n1 + " luego " + n3 + " y " + n2);
}
else if (n2 <= n1 && n2 <= n3) //Lo mismo para esta, vemos si el n2 es el menor entre los 3
{
    if (n1 <= n3) //Luego vemos cual es menor entre el y el 3
        Console.WriteLine("El menor es: " + n2 + " luego " + n1 + " y " + n3);
    else
        Console.WriteLine("El menor es: " + n2 + " luego " + n3 + " y " + n1);
}   
else if (n3 <= n1 && n3 <= n2) //Igual, a ver si el 3 es el menor
{
    if (n1 <= n2)//menor entre el 1 y 2
        Console.WriteLine("El menor es: " + n3 + " luego " + n1 + " y " + n2);
    else
        Console.WriteLine("El menor es: " + n3 + " luego " + n2 + " y " + n1);

}