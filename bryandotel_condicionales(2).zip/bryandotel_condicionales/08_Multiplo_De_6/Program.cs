﻿int num;
//Declaracion de variables 

//Pedimos el numero al usuario
Console.Write("Ingresa un numero: ");
//Lo convertimos a int
num = Convert.ToInt32(Console.ReadLine());

//Proceso para saber si es multiplo de 6
if (num % 6 == 0)
{
    //Mensaje de salida si es multiplo de 6
    Console.WriteLine(num + " es multiplo de 6");
}
else
{
    //Mensaje de salida sino es multiplo de 6
    Console.WriteLine(num + " no es multiplo de 6");
}