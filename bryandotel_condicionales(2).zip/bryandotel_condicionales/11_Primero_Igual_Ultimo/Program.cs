﻿int num;
int dig1;
int dig2;
//Declaracion de variables

//Interaccion con usuario, pedir numero
Console.Write("Ingresa un numero de 3 digitos: ");
//Convertimos el numero
num = Convert.ToInt32(Console.ReadLine());

//Validacion de si es un numero de 3 digitos
if (num < 100 || num >999)
    {
        //mensaje de salida si la condicion se cumple
    Console.WriteLine("Numero Invalido");
    }   
else
    {   
        //Sacamos el primer digito 
        dig1 = num / 100;
        dig2 = num % 10;
        //Y con modulo el ultimo digito

    //Comparamos si ambos digitos son iguales
    if (dig1 == dig2)
    {
        //mensaje de salida si lo son
    Console.WriteLine("Los numeros " + dig1 + " y " + dig2 + " son iguales");
    }
else
    { 
        //mensaje de salida sino lo son
    Console.WriteLine("Los numeros " + dig1 + " y " + dig2 + " no son iguales");
    }

}

