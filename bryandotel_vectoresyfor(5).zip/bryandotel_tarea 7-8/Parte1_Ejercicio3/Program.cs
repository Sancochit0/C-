﻿int num;
string nombre;
string matricula;
//Declaramos variables

//Pedimos nombre, matricula y un numero
Console.Write("Ingresa tu nombre: ");
nombre = Console.ReadLine()!;
Console.Write("Ingresa tu matricula: ");
matricula = Console.ReadLine()!;
Console.Write("Ingresa un numero: ");
num = Convert.ToInt32(Console.ReadLine());

//Primera condicional
if (num > 10 && num % 2 != 0)
{
    //Si se cumple, muestra de forma ascendente del 100 al 500 de 10 en 10
    for(int i0 = 100; i0 <= 500; i0 = i0 + 10)
    {
        //salida
        Console.WriteLine(i0);
    }
}
//segunda condicion
else if (num > 10 && num % 2 == 0)
{   
    //si se cumple, muestra un saludo 5 veces
    for (int i1 = 1; i1 <= 5; i1++)
    {   
        //salida
        Console.WriteLine("Hola bro");
    }
}
//tercera condicion
else
{   
    //si se cumple, mostramos el nombre y matricula ya ingresados 15 veces
    for (int i2 = 1; i2 <= 15; i2++)
    {   
        //salida
        Console.WriteLine("Hola " + nombre + ", tu matricula es: " + matricula);
    }
}
