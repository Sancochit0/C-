﻿/*
//PRIMERA FORMA USANDO UNICAMENTE FOR

int num1;
int num2;
//Declaracion de variables

//Usamos ciclo for para pedir ambos numeros una sola vez
for (int i = 0; i <= 0; i++)
{
    Console.Write("Ingresa el primero numero: ");
    num1 = Convert.ToInt32(Console.ReadLine());
    Console.Write("Ingresa el segundo numero: ");
    num2 = Convert.ToInt32(Console.ReadLine());

    //vemos si el primero es mayor
    if (num1 > num2)
    {
        //con otro for, lo mostramos de manera desendente
       for(int i1 = 0; num1 >= num2; i1++)
        {
            //Salida
            Console.WriteLine(num1);
            num1--;
            //lo restamos
        }
    }
    else
    {
        //lo mismo, xd
       for (int i2 = 0; num2 >= num1; i2--)
        {
            //salida
            Console.WriteLine(num2);
            num2 --;
            //restamos
        }
    }

}
*/


/*
//SEGUNDA FORMA USANDO WL CICLO WHILE 

//Aqui seria similar, pero usando un while, ya que no sabemos la cantidad de veces que se repetirar el descenso
int num1;
int num2;

for (int i = 0; i <= 0; i++)
{
    Console.Write("Ingresa el primero numero: ");
    num1 = Convert.ToInt32(Console.ReadLine());
    Console.Write("Ingresa el segundo numero: ");
    num2 = Convert.ToInt32(Console.ReadLine());

    if (num1 > num2)
    {
        while (num1 >= num2)
        {
            Console.WriteLine(num1);
            num1 --;
        }
    }
    else
    {
        while (num2 >= num1)
        {
            Console.WriteLine(num2);
            num2 --;
        }
    }

}
*/


