﻿int[] numeros = new int[5];
int[] copia = new int[5];
//Creacion de nuestro arreglo principal y el que sera nuestra copia

//Con un form pedimos los numeros
for(int i = 0; i < numeros.Length; i++)
{
    //interaccion
    Console.Write("Ingresa un numero: ");
    numeros[i] = Convert.ToInt32(Console.ReadLine());
    //entrada

    //validamos si la posicion actual es par, no el numero ingresado
    if(i % 2 == 0)
    {
        //si lo es, lo multiplicamos y lo agregamos a nuestro arreglo copia
        copia[i] = numeros[i] * 10;
    }
    else
    {
        //sino lo es, lo copiamos asi como esta
        copia[i] = numeros[i];
    }
}

for (int i = 0; i < numeros.Length; i++)
{
    //Salida
    Console.WriteLine(copia[i]);
}

