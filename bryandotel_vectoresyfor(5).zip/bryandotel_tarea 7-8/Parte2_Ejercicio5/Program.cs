﻿int[] numeros = new int[7];
bool encontrado = false;
//Creamos el arreglo y un booleano que usaremos luego

//Primero con un for pedimos los 7 numeros
for(int i=0; i < numeros.Length; i++)
{
    //interaccion
    Console.Write("Ingresa un numero: ");
    numeros[i] = Convert.ToInt32(Console.ReadLine());
    //entrada

    //luego verificamos si es igual a 23
    if(numeros[i] == 23)
    {
        //si lo es, mostramos un saludo
        Console.WriteLine("Hola bro");
        // y nuestro bool para a ser verdadero
        encontrado = true;
        break;
        //usamos un break para finalizar el programa y no siga
    }
}

//con una condicional, vericiamos si encontrado es falso, si lo es
if (encontrado == false)
{
    //mostramos un mensaje de despedida
    Console.WriteLine("Adios bro");
}