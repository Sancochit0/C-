﻿int numero;
int negativos = 0;
int repetir;
//Declaracion de las variables

//Pedimos la cantidad de veces que se repetira
Console.Write("Ingresa una cantidad: ");
repetir = Convert.ToInt32(Console.ReadLine());
//leemos la cantidad

//Con un ciclo for lo hacemos repetir
for (int i=1; i <= repetir; i++ )
{
    //Aqui pedimos un numero cada vez que se repite
    Console.Write("Ingresa un numero: ");
    numero = Convert.ToInt32(Console.ReadLine());

    //validamos si es negativo
    if(numero < 0)
    {
        negativos = negativos +1;
        //si es negativo, lo almacenamos en una variable contador
    }

}

Console.WriteLine("La cantidad de negativos fue: " + negativos);
//salida

