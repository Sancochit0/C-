﻿int [] numeros = new int[10];
int pares = 0;
int impares = 0;
//creacion del arreglo y de dos contadores

//Con un for pedimos los numeros
for(int i = 0; i < numeros.Length; i++)
{
    //interaccion
    Console.Write("Ingresa un numero: ");
    numeros[i] = Convert.ToInt32(Console.ReadLine());
    //entrada

    //condicion para ver si el numero ingresado es par o impar
    if (numeros[i] % 2 == 0)
    {
        //si lo es, aumentamos un numero en el contador de pares
        pares ++;
    }
    else
    {   
        //Si no lo es, aumentamos un numero en el contador de impares
        impares++;
    }
}

//Salida de ambos contadores
Console.WriteLine("La cantidad de pares fue: " + pares);
Console.WriteLine("La cantidad de impares fue: " + impares);
