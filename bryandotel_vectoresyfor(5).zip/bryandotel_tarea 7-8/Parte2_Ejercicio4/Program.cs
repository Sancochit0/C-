﻿int[] numeros = new int[5];
int sumatoria = 0;
//Creacion del arreglo que usaremos y declaracion de variable

//Con un for y la funcion 'Length' que sirve para leer la posicion del arreglo
//pedimos los 5 numeros
for (int i = 0; i < numeros.Length; i++)
{
    //interaccion
    Console.Write("Ingresa un numero: ");
    numeros[i] = Convert.ToInt32(Console.ReadLine());
    //entrada

    //proceso
    sumatoria = sumatoria + numeros[i];
}

//salida 
Console.WriteLine("La suma total es: " + sumatoria);
