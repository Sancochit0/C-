﻿//Programa que dependiendo de un numero ingresado, diga el mes del año correspondiente
int mes;
//Declaracion de variable

//Interaccion con usuario y entrada de datos
Console.Write("Ingresa un numero del 1 al 12 para saber el mes: ");
mes = Convert.ToInt32(Console.ReadLine());

//Ahora el proceso
switch (mes)
{
    case 1:
        Console.WriteLine("Estamos en el mes de Enero"); break;
    case 2: 
        Console.WriteLine("Estamos en el mes de Febrero"); break;
    case 3:
        Console.WriteLine("Estamos en el mes de Marzo"); break;
    case 4:
        Console.WriteLine("Estamos en el mes de Abril"); break;
    case 5:
        Console.WriteLine("Estamos en el mes de Mayo"); break;
    case 6:
        Console.WriteLine("Estamos en el mes de Junio"); break;
    case 7:
        Console.WriteLine("Estamos en el mes de Julio"); break;
    case 8:
        Console.WriteLine("Estamos en el mes de Agosto"); break;
    case 9:
        Console.WriteLine("Estamos en el mes de Septiembre"); break;
    case 10:
        Console.WriteLine("Estamos en el mes de Octubre"); break;
    case 11:
        Console.WriteLine("Estamos en el mes de Noviembre"); break;
    case 12:
        Console.WriteLine("Estamos en el mes de diciembre"); break;
    default:
        Console.WriteLine("Numero invalido bro, debe ser un numero del 1 al 12"); break;
    //Salidas 
}
