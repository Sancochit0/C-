﻿//Programa que dependiendo de una lentra ingresada (E, I, F), muestre una frase en un idioma
//(Español, Ingles, Frances)
char letra;
//Declaracion de variable

//Interaccion con usuario y entrada de datos
Console.Write("Ingresa una letra [E] Español [I] Ingles [F] Frances: ");
letra = Convert.ToChar(Console.ReadLine()!);

//Proceso
switch(letra)
{
    case 'E':
        Console.WriteLine("Klk bro"); break;
    case 'I':
        Console.WriteLine("are u okay n?"); break;
    case 'F':
        Console.WriteLine("Tranquille ou quoi"); break;
    default: 
        Console.WriteLine("Bro, opcion invalida, dale pa atra"); break;
    //Salidas
}
