﻿//Programa que ingresando un numero del 1 al 7 dia un dia de la semana
int DiaSemana;
//Declaracion de variable

//Interaccion con usuario y entrada de datos
Console.Write("Escriba un numero del 1 al 7 bro: ");
DiaSemana = Convert.ToInt32(Console.ReadLine()!);

//Proceso
switch(DiaSemana)
{
    case 1:
        Console.WriteLine("Por fin, ya e Domingo bro"); break;
    case 2: 
        Console.WriteLine("Todavia estamos a Lunes"); break;
    case 3:
        Console.WriteLine("Y todavia es Martes?"); break;
    case 4: 
        Console.WriteLine("Miercoles, casi casi jueves"); break;
    case 5:
        Console.WriteLine("Jueves, ojala fuera viernes"); break;
    case 6: 
        Console.WriteLine("Hoy e Viernes y el cuerpo lo sabe 🗣️"); break;
    case 7: 
        Console.WriteLine("Sabado, casi casi Domingo"); break;
    default:
        Console.WriteLine("Numero invalido bro, e de 1 al 7, vuelve a intentarlo"); break;
    //Salidas
}
