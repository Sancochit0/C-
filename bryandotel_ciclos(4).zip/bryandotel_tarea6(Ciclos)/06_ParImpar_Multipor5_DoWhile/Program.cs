﻿int n;
int aux;
//Declaracion de variable

//Interaccion y entrada
Console.Write("Ingresa un numero: ");
n = Convert.ToInt32(Console.ReadLine());

//proceso 
aux = n * 5;

//verificamos si es par
if (aux % 2 == 0)
{
   do
    {   
        //salida
        Console.WriteLine(n);
        n = n + 1;
        //incremento
    }
    while (n <= aux);
    //condicion
}

//si es impar
else if (aux % 2 != 0)
{
   do
    {
        //salida
        Console.WriteLine(aux);
        aux = aux - 1;
        //decremento
    }
    while(aux >= n);
    //condicion
}