﻿int n1;
int n2;
//Declaracion de variables

//Interaccion y entrada
Console.Write("Ingresa n1: ");
n1 = Convert.ToInt32(Console.ReadLine());
Console.Write("Ingresa n2: ");
n2 = Convert.ToInt32(Console.ReadLine());

//Primera validacion
if (n1 > n2)
{
    //proceso
    while (n2 <= n1)
    {
        //salida
        Console.WriteLine(n1);
        n1 = n1 - 1;
        //decremento
    }
}
//segunda validacion
else if(n1 <= n2)
{
    //proceso
    while(n1 <= n2)
    {
        //salida
        Console.WriteLine(n1);
        n1 = n1 + 1;
        //incremento
    }
}