﻿int n = 0;
//Declaracion de variables

//Proceso
while (n <= 1000)
{
    //salida
    Console.WriteLine(n);
    n = n + 5;
    //incremento
}
