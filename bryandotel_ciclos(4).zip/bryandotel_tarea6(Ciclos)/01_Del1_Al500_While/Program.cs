﻿int n = 1;
//Declaracion de variable

//Proceso
while (n <= 500)
{
    //Aqui mostraremos todos los numeros
    Console.WriteLine(n);
    n = n + 1;
    //Aqui lo incrementamos uno a 1, tabmiens se puede hacer n++;
}