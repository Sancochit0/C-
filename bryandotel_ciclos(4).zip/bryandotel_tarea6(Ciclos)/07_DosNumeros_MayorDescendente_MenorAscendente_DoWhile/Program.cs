﻿int n1;
int n2;
//Declaracion de variables 

//Interaccion y entrada 
Console.Write("Ingresa n1: ");
n1 = Convert.ToInt32(Console.ReadLine());
Console.Write("Ingresa n2: ");
n2 = Convert.ToInt32(Console.ReadLine());

//validacion
if (n1 > n2)
{
    do
    {
        //salida
        Console.WriteLine(n1);
        n1 = n1 - 1;
        //decremento
    }
    while (n2 <= n1);
    //condicion
}
//Validacion 
else if (n1 <= n2)
{
    do
    {
        //Salida
        Console.WriteLine(n1);
        n1 = n1 + 1;
    }
    while(n1 <= n2);
    //condicion
}int n1;
int n2;
//Declaracion de variables 

//Interaccion y entrada 
Console.Write("Ingresa n1: ");
n1 = Convert.ToInt32(Console.ReadLine());
Console.Write("Ingresa n2: ");
n2 = Convert.ToInt32(Console.ReadLine());

//validacion
if (n1 > n2)
{
    do
    {
        //salida
        Console.WriteLine(n1);
        n1 = n1 - 1;
        //decremento
    }
    while (n2 <= n1);
    //condicion
}
//Validacion 
else if (n1 <= n2)
{
    do
    {
        //Salida
        Console.WriteLine(n1);
        n1 = n1 + 1;
    }
    while(n1 <= n2);
}