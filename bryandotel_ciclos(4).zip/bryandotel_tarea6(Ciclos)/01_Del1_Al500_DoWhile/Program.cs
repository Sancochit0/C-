﻿int n = 1;
//Declaracion de variables

//Proceso 
do
{
    //Salida
    Console.WriteLine(n);
    n = n + 1;
    //incremento continuo hasta 500
}
while (n <= 500);
//Aqui ponemos la condicion 
