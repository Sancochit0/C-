﻿int n;
//Declaracion de variables

//Interaccion y entrada
Console.Write("Ingresa un numero: ");
n = Convert.ToInt32(Console.ReadLine());

//Proceso
while (n >= 0)
{
    //Salida
    Console.WriteLine(n);
    n = n - 1;
    //decremento
}
