﻿int n;
int aux;
//Declaracion de variables

//Interaccion y entrada
Console.Write("Ingresa un numero: ");
n = Convert.ToInt32(Console.ReadLine());

//proceso 1
aux = n * 5;

//Comprobar si es par
if (aux % 2 == 0)
{
    //Condicion
    while (n <= aux)
    {
        //salidan
        Console.WriteLine(n);
        n = n + 1;
        //incremento

    }
}
//ver si es impar
else if(aux % 2 != 0)
{
    //condicion
    while (aux >= n)
    {
        //salida
        Console.WriteLine(aux);
        aux = aux - 1;
        //decremento
    }
}
