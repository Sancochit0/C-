﻿int n = 1;
//Declaracion de variables

//Proceso
while (n <= 100)
{   
    //Verificar si es impar
    if (n % 2 != 0 )
    {
        //Salida
        Console.WriteLine(n);
       
    }
    //Incremento
     n = n + 1;
}
