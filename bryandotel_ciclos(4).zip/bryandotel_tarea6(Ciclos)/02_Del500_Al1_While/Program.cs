﻿int n = 500;
//Declaracion de variables

//Proceso
while (n >= 1)
{   
    //Salida
    Console.WriteLine(n);
    n = n - 1;
    //proceso
}
