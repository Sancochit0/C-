﻿int n = 0;
//Declaracion de variables

//Proceso
do
{
    //Salida
    Console.WriteLine(n);
    //incremento
    n = n + 5;
}
while (n <= 1000);
//Condicion
