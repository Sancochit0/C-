﻿int n = 500;
//Declaracion de variables

//Proceso
do
{   
    //Salida
    Console.WriteLine(n);
    n = n -1;
    //Proceso
}
while(n >= 1);
//Condicion
