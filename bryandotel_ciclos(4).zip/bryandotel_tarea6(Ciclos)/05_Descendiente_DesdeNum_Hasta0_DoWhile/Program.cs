﻿int n;
//Declaracion de variables

//Interacion y entrada 
Console.Write("Ingresa un numero: ");
n = Convert.ToInt32(Console.ReadLine());

//Proceso
do
{
    //Salida
    Console.WriteLine(n);
    n = n - 1;
    //decremento
}
while(n >= 0);
//condicion