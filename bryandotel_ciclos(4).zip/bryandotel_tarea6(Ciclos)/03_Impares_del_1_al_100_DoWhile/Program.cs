﻿int n = 1;
//Declaracion de variable

//Proceso
do
{
    //impar
    if (n % 2 != 0)
    {
        Console.WriteLine(n);
        //Salida
    }
     n = n + 1;
    //Incremento
}
while(n <= 100);
//Condicion
