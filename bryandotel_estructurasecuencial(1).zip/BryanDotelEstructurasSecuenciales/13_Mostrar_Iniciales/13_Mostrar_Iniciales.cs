﻿string primer_nom;
string segundo_nom;
string primer_apell;
string segundo_apell;
string inicial1;
string inicial2;
string inicial3;
string inicial4;
//Declaracion de variables

//Interaccion con usuario y entrada de datos
Console.Write("Ingresa tu primer nombre: ");
primer_nom =Console.ReadLine()!;
Console.Write("Ingresa tu segundo nombre: ");
segundo_nom = Console.ReadLine()!;
Console.Write("Ingresa tu primer apellido: ");
primer_apell = Console.ReadLine()!;   
Console.Write("Ingresa tu segundo apellido: ");

segundo_apell = Console.ReadLine()!;

//Salida de datos
inicial1 =(primer_nom.Substring(0,1));
inicial2 = (segundo_nom.Substring(0,1));
inicial3 = (primer_apell.Substring(0,1));
inicial4 = (segundo_apell.Substring(0,1));

Console.Write(inicial1);
Console.Write(inicial2);
Console.Write(inicial3);
Console.Write(inicial4);

     
