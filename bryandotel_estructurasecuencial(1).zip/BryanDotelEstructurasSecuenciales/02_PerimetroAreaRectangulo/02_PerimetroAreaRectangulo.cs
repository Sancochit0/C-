﻿Console.Write("Ingresa la base del rectangulo: ");
double baseRec = Convert.ToDouble(Console.ReadLine());
Console.Write("Escribe la altura de tu rectangulo: ");
double alturaRec = Convert.ToDouble(Console.ReadLine());
/*
En las primeras 4 lineas pedimos que ingrese la base y la altura, que son los datos que necesitamos
para calcular el area y el perimetro de un rectangulo y los convertimos a double.
*/
double AreaRec = baseRec * alturaRec;
double PerimetroRec = 2 * (baseRec + alturaRec); 
/*
Aqui declaramos los resultados como reales por los decimales
Y realizamos las operaciones 
*/
Console.WriteLine("El area de su rectangulo es: " + AreaRec);
Console.WriteLine("El perimetro de su rectangulo es: " + PerimetroRec);
//Mostramos resultado de ambas operaciones 
