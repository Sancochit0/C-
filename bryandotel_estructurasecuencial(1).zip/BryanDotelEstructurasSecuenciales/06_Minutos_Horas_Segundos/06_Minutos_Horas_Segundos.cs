﻿int minutos;
int horas;
int minutos_restantes;
//Declaramos las variables, esta vez usaremos entero

//Preguntamos que cantidad de minutos deseamos saber cuantas horas y minutos son
Console.Write("Ingresar una cantidad de minutos: ");
minutos = Convert.ToInt32(Console.ReadLine());
//Lo convertimos a entero la cantidad de minutos

//Hacemos la formula para saber cauntas horas son 
horas = (minutos / 60);
minutos_restantes = (minutos % 60);
//Y con el % (mod) sacamos residuo de la divison para saber lo que resta/sobra

Console.WriteLine("Sus minutos son " + horas + " horas y " + minutos_restantes + " minutos");
//Aqui mostramos cuantas horas y cuantos minutos son el tiempo que ingresamos