﻿double num1;
double num2;
double suma;
double resta;
double multiplicacion;
double division;
//Declaramos todo en double por si necesitamos hacer alguna operacion con decimal 

//Pedimos los 2 numeros 
Console.Write("Ingresa num1: ");
num1 = Convert.ToDouble(Console.ReadLine()!);
Console.Write("Ingresa num2: ");
num2 = Convert.ToDouble(Console.ReadLine()!);
//y convertimos ambos numeros ingresados a double

//realizamos cada operacion como pide el ejercicio
suma = num1 + num2;
resta = num1 - num2;
multiplicacion = num1 * num2;       
division = num1 / num2;

//Aqui mostramos los primeros 3 mensajes luego de resolver las operaciones
Console.WriteLine("El resultado de su suma es: " + suma);
Console.WriteLine("El resultado de su resta es: " + resta);
Console.WriteLine("El resultado de su multiplicacion es: " + multiplicacion);
Console.WriteLine("El resultado de su division es " + division);
