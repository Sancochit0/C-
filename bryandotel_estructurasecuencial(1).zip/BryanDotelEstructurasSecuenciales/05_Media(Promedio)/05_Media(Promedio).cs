﻿double num1;
double num2;
double num3;
double MediaPro;
//Declaramos todas las variables que vayamos a usar 

Console.Write("Ingrese el num1: ");
num1 = Convert.ToDouble(Console.ReadLine()!);
Console.Write("Ingrese el num2: ");
num2 = Convert.ToDouble(Console.ReadLine()!);
Console.Write("Ingresa el num3: ");
num3 = Convert.ToDouble(Console.ReadLine()!);
//Pedimos los 3 valores y los convertimos a double 

MediaPro = (num1 + num2 + num3) / 3;
//Realizamos la operacion, que es sumar todos los numeros y dividirlos entre 3 (cantidad de numeros sumados)
// O sea, si son 5 numeros, se divide entre 5
Console.WriteLine ("El promedio de sus numeros es: " + MediaPro);
Console.WriteLine ("El promedio de sus numeros es: " + Math.Round(MediaPro,2));
//Mostramos el resultado de dos formas, con todos sus decimales y solo 2 deciamles 
