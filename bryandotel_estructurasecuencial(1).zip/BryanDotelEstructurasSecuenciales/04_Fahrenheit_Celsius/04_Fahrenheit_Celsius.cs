﻿//Aqui pedimos que ingrese la cantidad de grados a convertir 
Console.Write("Ingresa los grados Fahrenheit: ");
double F = Convert.ToDouble(Console.ReadLine());
//Lo hacemos en double pq pueden dar numeros decimales 

//Declaramos tmb grados celcius en decimal
double C;

C = ((F - 32) * 5) / 9;
//Esta es la formula para convertir los grados

Console.WriteLine("Sus grados " + F + " convertidos a grados celcius son: " + C);
//Este es el resultado, al ser double, da decimales, por eso se puede hacer de esta forma





    