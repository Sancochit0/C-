﻿//Aqui pedimos el nombre de la persona
Console.Write("¿Cual es tu nombre? ");
string nombre = Console.ReadLine()!;
//Aqui declaramos nombre como cadena de texto y usamos "!" para decirle al programa que nunca estara vacio (Not null)

Console.WriteLine("Ola " + nombre + "¿Como estas?");
//Aqui el saludo que pide el ejercicio 

