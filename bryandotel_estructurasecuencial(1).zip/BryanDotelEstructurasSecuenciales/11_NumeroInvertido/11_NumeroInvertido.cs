﻿int num;
int d;
int u;
int invertido;
//Declaracion de variable que usaremos 

//Interaccion con el usuario
Console.Write("Ingresar un numero de dos cifras: "); 
num = Convert.ToInt32(Console.ReadLine());
//Entrada de datos

//Validamos si el numero esta en el rango y cumple con lo que le pedimos (que tenga 2 digitos)
if (num < 10 || num > 99 )
    Console.WriteLine("Numero invalido ");
    //Sino, le muestra este mensaje y el programa acaba
else
{
    //Si lo cumple el programa realiza lo siguiente 
    d = num / 10;
    u = num % 10;
    invertido = (u * 10) + d;
    Console.WriteLine("Su numero invertido es: " + invertido);
    //resultado 
} 
    


