﻿double totalCompra;
double Descuento;
double totalfinal; 
//Declaramos las variables que usaremos en este programa 

//Pedimos al usuario que ingrese el total de su compra
Console.Write("Ingrese el total de su compra: ");
totalCompra = Convert.ToDouble(Console.ReadLine());
//Y lo convertimos a double por si el total lleva algun decimal


//Sacamos el descuento, que es multiplicar nuestro total de compra
//Por la cantidad del descuento, en este caso, seria un 15% de descuento
//Luego lo dividiremos entre 100 ese resultado

Descuento = (totalCompra * 15) / 100;
totalfinal = (totalCompra - Descuento);
//Al final, a nuestro total, le restamos lo que nos dio la operacion anterior

Console.WriteLine("El total de su compra es: " + totalCompra);
Console.WriteLine("A su compra total se le descontaran " + Descuento + " pesos");
Console.WriteLine("Su nuevo total a pagar es: " + totalfinal);
//Aqui mostramos todo, nuestro total original antes del descuento
//La cantidad que se nos restara a nuestro total
//La cantidad que pagaremos al final