﻿double a;
double b;
double c;
//Declaracion de variables
//La tercera varible es para no perder uno de los numeros al intercambiar 

//Interacciones con el usuario
Console.Write("Ingresa el valor de a: ");
a = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingesa el valor de b: ");
b = Convert.ToDouble(Console.ReadLine());
//Entrada de datos

c = a;
a = b;
b = c;
//Proceso de como intercambiamos los numeros

Console.WriteLine("El valor de a es: " + a);
Console.WriteLine("El valor de b es: " + b);
//Resultado 
