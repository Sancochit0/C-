﻿double num;
double RaizCuadra;
double RaizCubica;
//Declaramos las variable que usaremos

//Pedimos que ingrese un numero el usuario
Console.Write("Ingresa un numero: ");
num = Convert.ToDouble (Console.ReadLine());
//Y lo convertimos en double 

/*
Usamos la función Math.Sqrt, que nos permite obtener
la raíz cuadrada de un número, la fórmula para calcularla
manualmente es más compleja de implementar en C#
*/
RaizCuadra = Math.Sqrt(num);
RaizCubica = Math.Cbrt(num);
//Lo mismo, usamos la funcion Math.Cbrt para la raiz cubica


Console.WriteLine("La raiz cuadrada de su numero es: " + RaizCuadra);
Console.WriteLine("La raiz cubica de su numero es: " + RaizCubica);
//Mostramos el resultado de ambos calculos


