﻿double SalarioBase;
double comision;
double ventas;
double SueldoMasComision;
//Declaramos las variables que usaremos que seran 3

//Le preguntamos al usuario cuanto es su sueldo mensual
Console.Write("¿Cuanto es tu sueldo mensual? ");
SalarioBase = Convert.ToDouble(Console.ReadLine());
//Lo convertimos a double por si el sueldo lleva algun valor decimal

//Preguntamos cuanto gano en ventas este mes
Console.Write("¿Cuanto ganaste en ventas este mes? ");
ventas = Convert.ToDouble(Console.ReadLine());

//Ya que nuestra comision sera un 10% mas, hacemos el calculo para ver cuanto sera este extra mensual
comision = (ventas * 0.10);
SueldoMasComision = SalarioBase + comision;
//Aqui sumamos el sueldo mensual mas la comision ganada 

Console.WriteLine("Su salario base es de " + SalarioBase + " y se le agregara una comision del 10%");
Console.WriteLine("Su comision final ganada son " + comision + " pesos");
Console.WriteLine("Su salario final de este mes sera: " + SueldoMasComision);
//Aqui mostramos todos los resultados
//El sueldo mensual
//La comision total ganada
//El nuevo sueldo que ganara este mes