﻿double num1;
double num2;
double distancia_num; 
//Declaracion de variables
 
//Primera interaccion con el usuario pidiendo un numero 
Console.Write("Ingresa num1: ");
num1 = Convert.ToDouble(Console.ReadLine()); //Primer ingreso de datos y lo convertimos a double
Console.Write("Ingresa num2: "); //Segunda interaccion 
num2 = Convert.ToDouble(Console.ReadLine()); //Segundo ingreso y a double

//Sacamos la distancia con la funcion Math.Abs, que es restar ambos numeros y ahi nos dira la distancia
distancia_num = Math.Abs(num1 - num2);
Console.WriteLine("La distancia entre los numeros ingresados es de " + distancia_num);
//Resultado